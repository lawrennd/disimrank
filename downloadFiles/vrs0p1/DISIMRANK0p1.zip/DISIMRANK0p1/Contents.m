% DISIMRANK toolbox
% Version 0.1		23-Feb-2010
% Copyright (c) 2010, Neil D. Lawrence
% 
, Neil D. Lawrence
% DROSGPDISIMLEARN Learns a GPDISIM model for given genes.
% DROSDOBOOTSTRAP Perform bootstrap sampling to assess significance of differences in rankings
% DROSGPDISIMLEARNWITHFIXEDINIT Learns a GPDISIM model for given genes.
% DROSFINDGENEINDS Find indices of given genes in a data set.
% DROSRUNODERANKINGS Runs the baseline quadrature ranking presented in the paper
% DROSPLOTACCURACYBARS Plot accuracies of alternative ranking methods.
% DROSGETDATA Get Drosophila data as processed by mmgMOS.
% DROSSCORETFTARGETLISTMT Score a list of candidate targets using multiple-target models.
% DROSSCORETFTARGETLIST Score a list of candidate targets.
% DROSODERANK Rank targets by fitting an ODE to raw expression data.
% DROSBOOTSTRAPEVALUATION Performs bootstrap sampling of rankings
% DISIMRANKTOOLBOXES Toolboxes for the DISIMRANK software.
% DROSCOMPUTECHIPDISTANCECURVE Compute the curve of distances to ChIP binding sites
% DROSREMOVEDUPLICATEGENES Remove duplicate probes from ranking.
% DROSPLOT Plot a GPDISIM model/models
% DROSMAPGENESTOIDS Map Drosophila FBgn gene identifiers to integers
% DROSPLOTEVALUATION Plot the accuracy figures appearing in the paper
% DROSPLOTCHIPDISTANCES Plot the ChIP binding site distance figures appearing in the paper
% DROSLOADDATA Loads the Drosophila data from the current directory
% DROSPRINTBOOTSTRAPMATRICES Print bootstrap sampling results as a LaTeX table
% DEMRUNRANKINGS Runs the rankings presented in the paper
% DROSMERGERESULTS Merge split results
% DROSCORRELATIONRANK Rank targets by expression profile correlation.
% DEMPLOTMODELS Plot sample model figures appearing in the paper
% DEMPLOTMEF2MODELS Plot Mef2 sample model figures appearing in the paper
% DROSINSITUPOSITIVES Filter genes by looking for positive in-situ annotations.
